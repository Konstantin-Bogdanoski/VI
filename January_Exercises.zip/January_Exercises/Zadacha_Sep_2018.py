from Python_neinformirano_prebaruvanje_final import *
from Python_informirano_prebaruvanje import *


def isValid(Covece, newCovece, Vrski): #Vrakja TRUE ako taa vrska seushte postoi vo grafot
    return (Covece, newCovece) in Vrski


class CollectStars(Problem):

    def __init__(self, initial, Star1, Star2, Vrski, Pominati = []):
        self.initial = int(initial) # Covece, Star1, Star2, Vrski, Pominati
        self.Star1 = int(Star1)
        self.Star2 = int(Star2)
        self.Vrski = tuple(Vrski)
        self.Pominati = tuple(Pominati)

    def goal_test(self, state):
        return self.Star1 == -1 and self.Star2 == -1

    def successor(self, state):
        successors = dict()
        Covece = state
        Star1 = int(self.Star1)
        Star2 = int(self.Star2)
        Vrski = tuple(self.Vrski)
        Pominati = tuple(self.Pominati)

        newPominati = list(Pominati)
        newVrski = list(Vrski)

        if(Covece in (4, 5, 6, 7, 9, 10, 12, 13, 14, 15)): #GORE
            newCovece = Covece-4# se ima pridvizheno nagore
            if(isValid(Covece, newCovece, newVrski)):
                newPominati.append((Covece, newCovece))
                newVrski.remove((Covece, newCovece))
                newVrski.remove((newCovece, Covece)) #Go brisheme dvonasochnoto povrzuvanje
                if(Star1 == newCovece): Star1 = -1
                if(Star2 == newCovece): Star2 = -1
                newState = (newCovece, Star1, Star2, tuple(newVrski), tuple(newPominati))
                successors['Gore'] = newState

        if (Covece in (0, 1, 2, 3, 5, 6, 8, 9, 10, 11)):  # DOLU
            newCovece = Covece + 4  # se ima pridvizheno nadolu
            if (isValid(Covece, newCovece, newVrski)):
                newPominati.append((Covece, newCovece))
                newVrski.remove((Covece, newCovece))
                newVrski.remove((newCovece, Covece))  # Go brisheme dvonasochnoto povrzuvanje
                if (Star1 == newCovece): Star1 = -1
                if (Star2 == newCovece): Star2 = -1
                newState = (newCovece, Star1, Star2, tuple(newVrski), tuple(newPominati))
                successors['Dolu'] = newState

        if (Covece in (1, 3, 5, 6, 7, 9, 10, 11, 13, 15)):  # Levo
            newCovece = Covece - 1  # se ima pridvizheno na levo
            if (isValid(Covece, newCovece, newVrski)):
                newPominati.append((Covece, newCovece))
                newVrski.remove((Covece, newCovece))
                newVrski.remove((newCovece, Covece))  # Go brisheme dvonasochnoto povrzuvanje
                if (Star1 == newCovece): Star1 = -1
                if (Star2 == newCovece): Star2 = -1
                newState = (newCovece, Star1, Star2, tuple(newVrski), tuple(newPominati))
                successors['Levo'] = newState

        if (Covece in (0, 2, 4, 5, 6, 8, 9, 10, 12, 14)):  # Desno
            newCovece = Covece + 1  # se ima pridvizheno na desno
            if (isValid(Covece, newCovece, newVrski)):
                newPominati.append((Covece, newCovece))
                newVrski.remove((Covece, newCovece))
                newVrski.remove((newCovece, Covece))  # Go brisheme dvonasochnoto povrzuvanje
                if (Star1 == newCovece): Star1 = -1
                if (Star2 == newCovece): Star2 = -1
                newState = (newCovece, Star1, Star2, tuple(newVrski), tuple(newPominati))
                successors['Desno'] = newState

        if (Covece == 5):  # Desno-Dolu
            newCovece = Covece + 5  # se ima pridvizheno desno-dolu
            if (isValid(Covece, newCovece, newVrski)):
                newPominati.append((Covece, newCovece))
                newVrski.remove((Covece, newCovece))
                newVrski.remove((newCovece, Covece))  # Go brisheme dvonasochnoto povrzuvanje
                if (Star1 == newCovece): Star1 = -1
                if (Star2 == newCovece): Star2 = -1
                newState = (newCovece, Star1, Star2, tuple(newVrski), tuple(newPominati))
                successors['Desno-Dolu'] = newState

        if (Covece == 10):  # Gore-Levo
            newCovece = Covece - 5  # se ima pridvizheno gore-levo
            if (isValid(Covece, newCovece, newVrski)):
                newPominati.append((Covece, newCovece))
                newVrski.remove((Covece, newCovece))
                newVrski.remove((newCovece, Covece))  # Go brisheme dvonasochnoto povrzuvanje
                if (Star1 == newCovece): Star1 = -1
                if (Star2 == newCovece): Star2 = -1
                newState = (newCovece, Star1, Star2, tuple(newVrski), tuple(newPominati))
                successors['Levo-Gore'] = newState

        return successors

    def actions(self, state):
        return self.successor(state).keys()

    def result(self, state, action):
        possible = self.successor(state)
        return possible[action]

    def h(self, node):
        return 0


# MAIN()
Vrski = ((0,1),(0,4),(1,0),(1,5),(2,3),(2,6),(3,2),(3,7),(4,0),(4,5),(5,4),(5,1),(5,9),(5,10),(5,6),(6,5),(6,2),(6,7),(6,10),\
         (7,6),(7,3),(8,12),(8,9),(9,8),(9,13),(9,5),(9,10),(10,9),(10,5),(10,6),(10,11),(10,14),(11,10),(11,15),(12,8),(12,13),\
         (13,12),(13,9),(14,10),(14,15),(15,14),(15,11)) #ALL CONNECTIONS BETWEEN POINTS
Covece = input() # Moze da bide vo opseg {5,6,9,10}
Star1 = input() # Opseg ALL - {Covece}
Star2 = input() # Opseg ALL - {Covece} - {Star1}
Pominati = ()
problem = CollectStars(Covece, Star1, Star2, Vrski, Pominati)
answer = astar_search(problem).solve()
print(answer)


