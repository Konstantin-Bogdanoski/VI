from Python_prebaruvanje_vo_konechen_graph_final import *



ABdistance = distance((2,1),(2,4))
BIdistance = distance((2,4),(8,5))
BCdistance = distance((2,4),(2,10))
HIdistance = distance((8,1),(8,5))
IJdistance = distance((8,5),(8,8))
FCdistance = distance((5,9),(2,10))
GCdistance = distance((4,11),(2,10))
CDdistance = distance((2,10),(2,15))
FGdistance = distance((5,9),(4,11))
FJdistance = distance((5,9),(8,8))
KGdistance = distance((8,13),(4,11))
LKdistance = distance((8,15),(8,13))
DEdistance = distance((2,15),(2,19))
DLdistance = distance((2,15),(8,15))
LMdistance = distance((8,15),(8,19))

graph = UndirectedGraph({
    "B": {"A": ABdistance, "I": BIdistance, "C": BCdistance},
    "I": {"H": HIdistance, "J": IJdistance},
    "C": {"F": FCdistance, "G": GCdistance, "D": CDdistance},
    "F": {"G": FGdistance, "J": FJdistance},
    "K": {"G": KGdistance, "L": LKdistance},
    "D": {"E": DEdistance, "L": DLdistance},
    "M": {"L": LMdistance}
})


graph.locations = dict(
A = (2,1) , B = (2,4) , C = (2,10) ,
D = (2,15) , E = (2,19) , F = (5,9) ,
G = (4,11) , H = (8,1) , I = (8,5),
J = (8,8) , K = (8,13) , L = (8,15),
M = (8,19))


Pocetok = input()
Stanica1 = input()
Stanica2 = input()
Kraj = input()


graphProblem1 = GraphProblem(Pocetok, Stanica1, graph)
graphProblem1_1 = GraphProblem(Stanica1, Kraj, graph)
graphProblem2 = GraphProblem(Pocetok, Stanica2, graph)
graphProblem2_2 = GraphProblem(Stanica2, Kraj,graph)


rez1 = astar_search(graphProblem1).solve()
rez1_1 = astar_search(graphProblem1_1).solve()
rez1Final = rez1 + rez1_1[1:len(rez1_1)]

rez1_cost = int(astar_search(graphProblem1).path_cost + astar_search(graphProblem1_1).path_cost)

rez2 = astar_search(graphProblem2).solve()
rez2_2 = astar_search(graphProblem2_2).solve()
rez2Final = rez2 + rez2_2[1:len(rez2_2)]

rez2_cost = int(astar_search(graphProblem2).path_cost + astar_search(graphProblem2_2).path_cost)

print(rez1_cost, rez2_cost)


if(len(rez1Final) <= len(rez2Final)):
    print(rez1Final)
else:
    print(rez2Final)


"""
---------------------------------------------------------------

Sample input

'A'
'J'
'K'
'E'


Sample output

['A', 'B', 'I', 'J', 'F', 'C', 'D', 'E']
"""