from Python_informirano_prebaruvanje import *
from Python_neinformirano_prebaruvanje_final import *

def clickOnPosition(position, state):
    tempState = list()

    for i in state:
        tempRow = list(i)
        tempState.append(tempRow)

    for i in range(len(state)):
        tempRow = list(state[i])
        for j in range(len(tempRow)):
            if(position[0] == i and position[1] == j):
                tempState[i][j] = tempState[i][j] * (-1)
                if(i != 0):
                    tempState[i - 1][j] = tempState[i-1][j] * (-1)
                if(i < len(state) - 1):
                    tempState[i + 1][j] = tempState[i + 1][j] * (-1)
                if(j != 0):
                    tempState[i][j - 1] = tempState[i][j - 1] * (-1)
                if(j < len(tempRow) - 1):
                    tempState[i][j + 1] = tempState[i][j + 1] * (-1)

    theTuple = list()
    for i in tempState:
        tempRow = tuple(i)
        theTuple.append(tempRow)

    return tuple(theTuple)


class Clicks(Problem):
    def __init__(self, initial, goal):
        self.initial = initial
        self.goal = goal

    def goal_test(self, state):
        for i in state:
            for j in i:
                if(j == -1):
                    return False
        return True

    def successor(self, state):
        successors = dict()
        for i in range(len(state)):
            tempRow = state[i]
            for j in range(len(tempRow)):
                tempState = clickOnPosition([i,j],state)
                successors["x: " + str(i) + " | y: " + str(j)] = tempState
        return successors

    def h(self, node):
        count = 0
        for i in self.initial:
            for j in i:
                if(j==1):
                    count += 1
        return count

    def actions(self, state):
        return self.successor(state).keys()

    def result(self, state, action):
        possible = self.successor(state)
        return possible[action]

    def path_cost(self, c, state1, action, state2):
        """Return the cost of a solution path that arrives at state2 from
        state1 via action, assuming cost c to get up to state1. If the problem
        is such that the path doesn't matter, this function will only look at
        state2.  If the path does matter, it will consider c and maybe state1
        and action. The default method costs 1 for every step in the path."""
        return c + 1

    def value(self):
        """For optimization problems, each state has a value.  Hill-climbing
        and related algorithms try to maximize this value."""
        raise NotImplementedError



N = int(input())
polinja = list(map(int, input().split(',')))
#polinja = input().split(",")

matrix=list()
goalMatrix=list()
k=0

for i in range(N):
    row=[]
    goalRow=[]
    for j in range(N):
        row.append(polinja[k])
        goalRow.append(1)
        k+=1
    matrix.append(tuple(row))
    goalMatrix.append(tuple(goalRow))


myMatrix = tuple(matrix)
myGoal = tuple(goalMatrix)

print(myMatrix)
print(myGoal)

problem = Clicks(myMatrix, myGoal)
#answer = breadth_first_graph_search(problem)
answer = astar_search(problem)
print(answer.solve())