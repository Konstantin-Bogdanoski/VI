from Python_neinformirano_prebaruvanje_final import *



def moveKocka1Left(state):
    Covece = state[0]
    Kocka1 = state[1]
    newState = list(state)

    if (Covece[1] == Kocka1[1] and Covece[0] == Kocka1[0]+1 and Kocka1[0]>0):  # CoveceX = KockaX + 1 and CoveceY = KockaY (desno od kockata)
        Covece[0] -= 1
        Kocka1[0] -= 1

    newState[0] = Covece
    newState[1] = Kocka1

    return newState


def moveKocka2Left(state):
    Covece = state[0]
    Kocka2 = state[2]
    newState = list(state)

    if (Covece[1] == Kocka2[1] and Covece[0] == Kocka2[0]+1 and Kocka2[0]>0):  # CoveceX = KockaX + 1 and CoveceY = KockaY (desno od kockata)
        Covece[0] -= 1
        Kocka2[0] -= 1

    newState[0] = Covece
    newState[2] = Kocka2

    return newState


def moveKocka3Left(state):
    Covece = state[0]
    Kocka3 = state[3]
    newState = list(state)

    if (Covece[1] == Kocka3[1] and Covece[0] == Kocka3[0]+1 and Kocka3[0]>0):  # CoveceX = KockaX + 1 and CoveceY = KockaY (desno od kockata)
        Covece[0] -= 1
        Kocka3[0] -= 1

    newState[0] = Covece
    newState[3] = Kocka3

    return newState
########################################################
#KOCKA DOLU
########################################################
def moveKocka1Down(state):
    Covece = state[0]
    Kocka1 = state[1]
    newState = list(state)

    if (Covece[1] == Kocka1[1] + 1 and Covece[0] == Kocka1[0] and Kocka1[1] > 0):  # CoveceX = KockaX and CoveceY = KockaY + 1 (nad kockata)
        Covece[1] -= 1
        Kocka1[1] -= 1

    newState[0] = Covece
    newState[1] = Kocka1

    return newState


def moveKocka2Down(state):
    Covece = state[0]
    Kocka2 = state[2]
    newState = list(state)

    if (Covece[1] == Kocka2[1] + 1 and Covece[0] == Kocka2[0] and Kocka2[1] > 0):  # CoveceX = KockaX and CoveceY = KockaY + 1 (nad kockata)
        Covece[1] -= 1
        Kocka2[1] -= 1

    newState[0] = Covece
    newState[2] = Kocka2

    return newState


def moveKocka3Down(state):
    Covece = state[0]
    Kocka3 = state[3]
    newState = list(state)

    if (Covece[1] == Kocka3[1] + 1 and Covece[0] == Kocka3[0] and Kocka3[1] > 0):  # CoveceX = KockaX and CoveceY = KockaY + 1 (nad kockata)
        Covece[1] -= 1
        Kocka3[1] -= 1

    newState[0] = Covece
    newState[3] = Kocka3

    return newState


def moveKocka1Up(state):
    Covece = state[0]
    Kocka1 = state[1]
    newState = list(state)

    if(Covece[1] == Kocka1[1]-1 and Covece[0] == Kocka1[0] and Kocka1[1] < 10): #CoveceX = KockaX and CoveceY = KockaY - 1 (pod kockata)
        Covece[1] += 1
        Kocka1[1] += 1

    newState[0] = Covece
    newState[1] = Kocka1

    return newState


def moveKocka2Up(state):
    Covece = state[0]
    Kocka2 = state[2]
    newState = list(state)

    if (Covece[1] == Kocka2[1] - 1 and Covece[0] == Kocka2[0] and Kocka2[1] < 10):  # CoveceX = KockaX and CoveceY = KockaY - 1 (pod kockata)
        Covece[1] += 1
        Kocka2[1] += 1

    newState[0] = Covece
    newState[2] = Kocka2

    return newState


def moveKocka3Up(state):
    Covece = state[0]
    Kocka3 = state[3]
    newState = list(state)

    if (Covece[1] == Kocka3[1] - 1 and Covece[0] == Kocka3[0] and Kocka3[1] < 10):  # CoveceX = KockaX and CoveceY = KockaY - 1 (pod kockata)
        Covece[1] += 1
        Kocka3[1] += 1

    newState[0] = Covece
    newState[1] = Kocka3

    return newState


class TenByTen(Problem):

    def __init__(self, Covece, Kocka1, Kocka2, Kocka3, K1F, K2F, K3F):
        self.Covece = Covece
        self.Kocka1 = Kocka1
        self.Kocka2 = Kocka2
        self.Kocka3 = Kocka3
        self.K1F = K1F
        self.K2F = K2F
        self.K3F = K3F


    def goal_test(self, state):
        """ Vraka true ako sostojbata e celna """
        return (self.Kocka1 == self.K1F and self.Kocka2 == self.K2F and self.Kocka3 == self.K3F)
        #Kocka1 e [X,Y], K1F e [X,Y], Kocka1 tekovna polozhba na kocka1, K1F e krajna polozhba na kockata
        #istoto vazhi i za Kocka2, Kocka3, K2F, K3F

    def successor(self, state):
        """Vraka recnik od sledbenici na sostojbata"""
        successors = dict()



    def actions(self, state):
        return self.successor(state).keys()

    def result(self, state, action):
        possible = self.successor(state)
        return possible[action]